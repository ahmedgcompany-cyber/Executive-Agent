# Executive Agent

A local-first executive AI agent that can code apps, control browsers, automate desktop applications, and manage your workflows.

## Overview

Executive Agent is built on the foundation of Clawd Code, transformed into a comprehensive local operator that can:

- **Code & Build**: Generate code, debug, test, and package applications
- **Browse & Automate**: Control web browsers, fill forms, extract data
- **Desktop Control**: Launch and control installed applications
- **Creative Software**: Interface with Photoshop, Illustrator, After Effects, Blender, AutoCAD
- **Memory & Profiles**: Store your information for automated form filling
- **Workflows**: Record and replay successful procedures
- **Skills**: Install and manage reusable capabilities

## Architecture

```
executive-agent/
├── src/
│   ├── agents/           # Specialist agents
│   │   ├── commander_agent.py    # Task routing
│   │   ├── coder_agent.py        # Software development
│   │   ├── browser_agent.py      # Web automation
│   │   ├── desktop_agent.py      # Desktop control
│   │   ├── job_agent.py          # Job applications
│   │   ├── sales_agent.py        # Sales research
│   │   ├── content_agent.py      # Content creation
│   │   ├── skill_agent.py        # Skill management
│   │   └── memory_agent.py       # Memory operations
│   ├── tools_ext/        # Extended tools
│   │   ├── browser_tools.py      # Playwright-based browser control
│   │   ├── form_tools.py         # Intelligent form filling
│   │   ├── desktop_tools.py      # Desktop automation
│   │   ├── vision_tools.py       # Screen analysis
│   │   ├── profile_tools.py      # Profile access
│   │   ├── workflow_tools.py     # Workflow recording
│   │   ├── skill_tools.py        # Skill management
│   │   └── app_control_tools.py  # App-specific control
│   ├── memory/           # Memory storage
│   │   ├── profile_store.py      # User profiles
│   │   ├── workflow_store.py     # Workflow storage
│   │   └── project_store.py      # Project memory
│   ├── integrations/     # App adapters
│   │   ├── photoshop_adapter.py
│   │   ├── illustrator_adapter.py
│   │   ├── aftereffects_adapter.py
│   │   ├── autocad_adapter.py
│   │   ├── blender_adapter.py
│   │   └── office_adapter.py
│   ├── prompts/          # Agent prompts
│   ├── gui/              # GUI components
│   ├── cli.py            # CLI entry point
│   ├── repl.py           # Interactive REPL
│   └── main.py           # Main entry point
├── config/               # Configuration files
├── profiles/             # User profiles
├── skills/               # Installed skills
└── workflows/            # Saved workflows
```

## Installation

```bash
# Clone the repository
git clone <repository-url>
cd executive-agent

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install Playwright browsers
playwright install
```

## Usage

### CLI Mode

```bash
# Start interactive CLI
python -m src.main

# Execute a single goal
python -m src.main --goal "Create a Python script that downloads images"

# Show help
python -m src.main --help
```

### GUI Mode

```bash
# Start GUI application
python -m src.main --gui
```

### REPL Mode

```bash
# Start interactive REPL
python -m src.repl
```

## Configuration

Edit the configuration files in `config/`:

- `settings.yaml` - General application settings
- `models.yaml` - LLM provider configuration
- `permissions.yaml` - Permission settings
- `apps.yaml` - Application paths and settings
- `skills.yaml` - Skill system configuration

## Profile Setup

Edit your profile in `profiles/user_profile.json`:

```json
{
  "name": "Your Name",
  "location": "Your Location",
  "emails": ["your@email.com"],
  "phones": ["+1234567890"],
  "linkedin": "https://linkedin.com/in/yourprofile",
  "job_titles": ["Developer", "Designer"],
  "writing_style": "professional"
}
```

Edit job application answers in `profiles/job_answers.json`.

## Agents

### Commander Agent
Routes tasks to the appropriate specialist agent based on the goal.

### Coder Agent
Handles software development tasks:
- Code generation
- File operations
- Build and test execution
- Debugging

### Browser Agent
Handles web automation:
- Navigate websites
- Fill forms
- Upload files
- Extract data

### Desktop Agent
Handles desktop application control:
- Launch applications
- Control UI elements
- Send keyboard shortcuts
- Capture screenshots

### Job Agent
Handles job applications:
- Match job requirements
- Fill application forms
- Generate cover letters
- Select resume variants

### Content Agent
Handles content creation:
- YouTube descriptions
- Social media posts
- Marketing copy
- Outreach emails

### Sales Agent
Handles sales tasks:
- Market research
- Lead structuring
- Outreach drafting
- Competitor analysis

### Skill Agent
Manages skill lifecycle:
- Search skills
- Download and install
- Update registry
- Enable/disable skills

### Memory Agent
Manages memory operations:
- Profile access
- Workflow retrieval
- Project notes
- Task history

## Tools

### Browser Tools
- `browser_open` - Open browser and navigate to URL
- `browser_click` - Click element
- `browser_type` - Type text into input
- `browser_select` - Select dropdown option
- `browser_upload` - Upload file
- `browser_screenshot` - Take screenshot
- `browser_extract_fields` - Extract form fields

### Desktop Tools
- `launch_application` - Launch app
- `focus_window` - Focus window
- `list_controls` - List UI controls
- `click_control` - Click control
- `type_into_control` - Type into control
- `send_hotkey` - Send keyboard shortcut
- `capture_window` - Capture window screenshot

### Vision Tools
- `capture_screen_region` - Capture screen area
- `compare_screens` - Compare screenshots
- `locate_visual_target` - Find image on screen
- `wait_for_visual_target` - Wait for image

### Profile Tools
- `load_user_profile` - Load profile data
- `get_profile_field` - Get specific field
- `get_job_answer` - Get job answer
- `get_default_resume` - Get resume path

### Workflow Tools
- `start_workflow_recording` - Start recording
- `record_workflow_step` - Record step
- `save_workflow` - Save workflow
- `load_workflow` - Load workflow
- `replay_workflow` - Replay workflow

### Skill Tools
- `search_skill_sources` - Search for skills
- `download_skill` - Download skill
- `install_skill` - Install skill
- `list_skills` - List installed skills
- `uninstall_skill` - Remove skill

## Application Adapters

### Photoshop Adapter
- `open_file` - Open image
- `save_document` - Save document
- `export_document` - Export to format
- `run_action` - Run Photoshop action
- `remove_background` - Remove background
- `resize_image` - Resize image

### Illustrator Adapter
- `open_file` - Open document
- `save_document` - Save document
- `export_document` - Export to format
- `export_social_pack` - Export social media sizes
- `trace_image` - Trace raster to vector

### After Effects Adapter
- `open_file` - Open project
- `render_queue` - Add to render queue
- `render_reel` - Render multiple compositions
- `export_frame` - Export single frame

### Blender Adapter
- `launch` - Launch Blender
- `run_script` - Run Python script
- `render` - Render scene
- `batch_render` - Batch render files
- `export_model` - Export 3D model

### AutoCAD Adapter
- `open_file` - Open drawing
- `save_document` - Save document
- `export_pdf` - Export to PDF
- `plot_drawing` - Plot drawing
- `run_script` - Run AutoCAD script

### Office Adapter
- `open_word_document` - Open Word doc
- `export_word_to_pdf` - Export to PDF
- `open_excel_workbook` - Open Excel file
- `create_excel_chart` - Create chart
- `open_powerpoint_presentation` - Open presentation
- `export_powerpoint_to_pdf` - Export to PDF

## Workflow Recording

Record successful workflows for later replay:

```python
# Start recording
workflow_tools.start_workflow_recording("job_apply_linkedin", "jobs")

# Record steps
workflow_tools.record_workflow_step("browser_open", {"url": "https://linkedin.com/jobs"})
workflow_tools.record_workflow_step("fill_form", {"use_profile": True})

# Save workflow
workflow_tools.save_workflow()

# Replay later
workflow_tools.replay_workflow("job_apply_linkedin", "jobs")
```

## Skill System

Skills are reusable capabilities that can be installed:

```python
# Search for skills
skill_tools.search_skill_sources("job_apply")

# Download and install
skill_tools.download_skill("https://skills.example.com/job_apply.zip")
skill_tools.install_skill("skills/quarantine/job_apply.zip")

# List installed skills
skill_tools.list_skills()

# Use skill
commander.execute_goal("Use job_apply skill for LinkedIn", context)
```

## Development

```bash
# Run tests
pytest tests/

# Format code
black src/
isort src/

# Type check
mypy src/
```

## License

MIT License - See LICENSE file

## Acknowledgments

Built on the foundation of Clawd Code, a Python reimplementation of Claude Code.
