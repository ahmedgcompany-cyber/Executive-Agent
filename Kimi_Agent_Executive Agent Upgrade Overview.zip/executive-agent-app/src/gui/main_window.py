"""Main window for the Executive Agent GUI."""

from pathlib import Path

try:
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QTabWidget, QTextEdit, QLineEdit, QPushButton,
        QLabel, QListWidget, QSplitter, QStatusBar,
        QMenuBar, QMenu, QFileDialog, QMessageBox,
    )
    from PySide6.QtCore import Qt, QThread, Signal
    from PySide6.QtGui import QAction
    PYSIDE_AVAILABLE = True
except ImportError:
    PYSIDE_AVAILABLE = False
    # Dummy classes for type hints
    class QMainWindow:
        pass


class AgentWorker(QThread if PYSIDE_AVAILABLE else object):
    """Worker thread for running agent tasks."""

    finished = Signal(dict) if PYSIDE_AVAILABLE else None
    progress = Signal(str) if PYSIDE_AVAILABLE else None

    def __init__(self, commander, goal):
        """Initialize worker.

        Args:
            commander: Commander agent
            goal: Task goal
        """
        super().__init__() if PYSIDE_AVAILABLE else None
        self.commander = commander
        self.goal = goal

    def run(self):
        """Run the task."""
        try:
            self.progress.emit("Analyzing goal...")
            result = self.commander.execute_goal(self.goal, {})
            self.finished.emit(result)
        except Exception as e:
            self.finished.emit({"success": False, "error": str(e)})


class MainWindow(QMainWindow if PYSIDE_AVAILABLE else object):
    """Main application window."""

    def __init__(self):
        """Initialize main window."""
        if PYSIDE_AVAILABLE:
            super().__init__()
            self.setWindowTitle("Executive Agent")
            self.setMinimumSize(1200, 800)

            self._setup_ui()
            self._setup_menu()
            self._setup_status_bar()

            # Initialize agents (placeholder)
            self.commander = None

    def _setup_ui(self):
        """Set up the user interface."""
        if not PYSIDE_AVAILABLE:
            return

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QHBoxLayout(central_widget)

        # Splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(splitter)

        # Left panel - Chat
        chat_widget = QWidget()
        chat_layout = QVBoxLayout(chat_widget)

        # Chat history
        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        chat_layout.addWidget(QLabel("Chat"))
        chat_layout.addWidget(self.chat_history)

        # Input area
        input_layout = QHBoxLayout()
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Enter your goal...")
        self.message_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.message_input)

        self.send_button = QPushButton("Send")
        self.send_button.clicked.connect(self.send_message)
        input_layout.addWidget(self.send_button)

        chat_layout.addLayout(input_layout)
        splitter.addWidget(chat_widget)

        # Right panel - Tabs
        right_tabs = QTabWidget()

        # Tasks tab
        self.tasks_list = QListWidget()
        right_tabs.addTab(self.tasks_list, "Tasks")

        # Workflows tab
        self.workflows_list = QListWidget()
        right_tabs.addTab(self.workflows_list, "Workflows")

        # Skills tab
        self.skills_list = QListWidget()
        right_tabs.addTab(self.skills_list, "Skills")

        # Profile tab
        profile_widget = QTextEdit()
        profile_widget.setPlainText("Profile information will be displayed here.")
        right_tabs.addTab(profile_widget, "Profile")

        # Logs tab
        self.logs_text = QTextEdit()
        self.logs_text.setReadOnly(True)
        right_tabs.addTab(self.logs_text, "Logs")

        splitter.addWidget(right_tabs)
        splitter.setSizes([700, 500])

    def _setup_menu(self):
        """Set up the menu bar."""
        if not PYSIDE_AVAILABLE:
            return

        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")

        new_action = QAction("New Session", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_session)
        file_menu.addAction(new_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Tools menu
        tools_menu = menubar.addMenu("Tools")

        browser_action = QAction("Browser Tools", self)
        browser_action.triggered.connect(self.open_browser_tools)
        tools_menu.addAction(browser_action)

        desktop_action = QAction("Desktop Tools", self)
        desktop_action.triggered.connect(self.open_desktop_tools)
        tools_menu.addAction(desktop_action)

        # Help menu
        help_menu = menubar.addMenu("Help")

        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def _setup_status_bar(self):
        """Set up the status bar."""
        if not PYSIDE_AVAILABLE:
            return

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")

    def send_message(self):
        """Send a message."""
        if not PYSIDE_AVAILABLE:
            return

        message = self.message_input.text().strip()
        if not message:
            return

        # Add to chat history
        self.chat_history.append(f"<b>You:</b> {message}")
        self.message_input.clear()

        # Process the message
        self.process_goal(message)

    def process_goal(self, goal: str):
        """Process a user goal.

        Args:
            goal: User's goal
        """
        if not PYSIDE_AVAILABLE:
            return

        self.status_bar.showMessage(f"Processing: {goal[:50]}...")

        # This would use the commander agent
        # For now, show a placeholder response
        self.chat_history.append(f"<b>Agent:</b> Processing your request: {goal}")
        self.chat_history.append("<i>This would route to the appropriate specialist agent.</i>")

        self.status_bar.showMessage("Ready")

    def new_session(self):
        """Start a new session."""
        self.chat_history.clear()
        self.tasks_list.clear()
        self.logs_text.clear()

    def open_browser_tools(self):
        """Open browser tools dialog."""
        self.chat_history.append("<i>Browser tools would open here</i>")

    def open_desktop_tools(self):
        """Open desktop tools dialog."""
        self.chat_history.append("<i>Desktop tools would open here</i>")

    def show_about(self):
        """Show about dialog."""
        if not PYSIDE_AVAILABLE:
            return

        QMessageBox.about(
            self,
            "About Executive Agent",
            "<h2>Executive Agent 1.0</h2>"
            "<p>Local-first executive AI agent for coding, browser automation, and desktop control.</p>"
            "<p>Built on Clawd Code foundation.</p>",
        )
