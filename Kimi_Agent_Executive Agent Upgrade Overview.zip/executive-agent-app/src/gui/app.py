"""Main GUI application."""

import sys
from pathlib import Path

# Check if PySide6 is available
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import Qt
    PYSIDE_AVAILABLE = True
except ImportError:
    PYSIDE_AVAILABLE = False

from .main_window import MainWindow


class ExecutiveAgentApp:
    """Main GUI application class."""

    def __init__(self):
        """Initialize the application."""
        self.app = None
        self.main_window = None

    def run(self) -> int:
        """Run the GUI application.

        Returns:
            Exit code
        """
        if not PYSIDE_AVAILABLE:
            print("Error: PySide6 not installed. Run: pip install pyside6")
            return 1

        self.app = QApplication(sys.argv)
        self.app.setApplicationName("Executive Agent")
        self.app.setApplicationVersion("1.0.0")

        self.main_window = MainWindow()
        self.main_window.show()

        return self.app.exec()


def main():
    """Entry point for GUI application."""
    app = ExecutiveAgentApp()
    return app.run()


if __name__ == "__main__":
    sys.exit(main())
