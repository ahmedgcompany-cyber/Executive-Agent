"""Task panel for the GUI."""

from pathlib import Path

try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout,
        QListWidget, QListWidgetItem, QPushButton,
        QLabel, QProgressBar, QMenu,
    )
    from PySide6.QtCore import Qt, Signal
    from PySide6.QtGui import QAction
    PYSIDE_AVAILABLE = True
except ImportError:
    PYSIDE_AVAILABLE = False


class TaskPanel(QWidget if PYSIDE_AVAILABLE else object):
    """Task panel widget."""

    task_selected = Signal(str) if PYSIDE_AVAILABLE else None
    task_cancelled = Signal(str) if PYSIDE_AVAILABLE else None

    def __init__(self, parent=None):
        """Initialize task panel.

        Args:
            parent: Parent widget
        """
        if PYSIDE_AVAILABLE:
            super().__init__(parent)
            self._setup_ui()
            self.tasks = {}

    def _setup_ui(self):
        """Set up the UI."""
        if not PYSIDE_AVAILABLE:
            return

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        # Header
        header_layout = QHBoxLayout()
        header = QLabel("Active Tasks")
        header.setStyleSheet("font-size: 16px; font-weight: bold;")
        header_layout.addWidget(header)

        # Clear button
        clear_btn = QPushButton("Clear Completed")
        clear_btn.clicked.connect(self.clear_completed)
        header_layout.addWidget(clear_btn)

        layout.addLayout(header_layout)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        # Task list
        self.task_list = QListWidget()
        self.task_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.task_list.customContextMenuRequested.connect(self.show_context_menu)
        self.task_list.itemClicked.connect(self.on_task_selected)
        layout.addWidget(self.task_list)

    def add_task(self, task_id: str, description: str, status: str = "pending"):
        """Add a task to the list.

        Args:
            task_id: Task identifier
            description: Task description
            status: Task status
        """
        if not PYSIDE_AVAILABLE:
            return

        self.tasks[task_id] = {
            "description": description,
            "status": status,
        }

        item = QListWidgetItem(f"[{status.upper()}] {description}")
        item.setData(Qt.UserRole, task_id)
        self._set_item_color(item, status)
        self.task_list.addItem(item)

    def update_task(self, task_id: str, status: str, progress: int = None):
        """Update a task's status.

        Args:
            task_id: Task identifier
            status: New status
            progress: Optional progress percentage
        """
        if not PYSIDE_AVAILABLE:
            return

        if task_id not in self.tasks:
            return

        self.tasks[task_id]["status"] = status

        # Find and update the item
        for i in range(self.task_list.count()):
            item = self.task_list.item(i)
            if item.data(Qt.UserRole) == task_id:
                description = self.tasks[task_id]["description"]
                item.setText(f"[{status.upper()}] {description}")
                self._set_item_color(item, status)
                break

        if progress is not None:
            self.progress_bar.setValue(progress)
            self.progress_bar.setVisible(True)

    def remove_task(self, task_id: str):
        """Remove a task from the list.

        Args:
            task_id: Task identifier
        """
        if not PYSIDE_AVAILABLE:
            return

        if task_id in self.tasks:
            del self.tasks[task_id]

        for i in range(self.task_list.count()):
            item = self.task_list.item(i)
            if item.data(Qt.UserRole) == task_id:
                self.task_list.takeItem(i)
                break

    def _set_item_color(self, item, status: str):
        """Set item color based on status.

        Args:
            item: List item
            status: Task status
        """
        if not PYSIDE_AVAILABLE:
            return

        colors = {
            "pending": "#ffc107",
            "running": "#007bff",
            "completed": "#28a745",
            "failed": "#dc3545",
            "cancelled": "#6c757d",
        }

        color = colors.get(status, "#000000")
        item.setForeground(color)

    def on_task_selected(self, item):
        """Handle task selection.

        Args:
            item: Selected item
        """
        if PYSIDE_AVAILABLE:
            task_id = item.data(Qt.UserRole)
            self.task_selected.emit(task_id)

    def show_context_menu(self, position):
        """Show context menu for task.

        Args:
            position: Menu position
        """
        if not PYSIDE_AVAILABLE:
            return

        item = self.task_list.itemAt(position)
        if not item:
            return

        menu = QMenu()

        cancel_action = QAction("Cancel Task", self)
        cancel_action.triggered.connect(lambda: self.cancel_task(item))
        menu.addAction(cancel_action)

        remove_action = QAction("Remove", self)
        remove_action.triggered.connect(lambda: self.remove_task_item(item))
        menu.addAction(remove_action)

        menu.exec(self.task_list.mapToGlobal(position))

    def cancel_task(self, item):
        """Cancel a task.

        Args:
            item: Task item
        """
        if PYSIDE_AVAILABLE:
            task_id = item.data(Qt.UserRole)
            self.update_task(task_id, "cancelled")
            self.task_cancelled.emit(task_id)

    def remove_task_item(self, item):
        """Remove a task item.

        Args:
            item: Task item
        """
        if PYSIDE_AVAILABLE:
            task_id = item.data(Qt.UserRole)
            self.remove_task(task_id)

    def clear_completed(self):
        """Clear completed tasks."""
        if not PYSIDE_AVAILABLE:
            return

        to_remove = []
        for task_id, task in self.tasks.items():
            if task["status"] in ["completed", "failed", "cancelled"]:
                to_remove.append(task_id)

        for task_id in to_remove:
            self.remove_task(task_id)

    def clear_all(self):
        """Clear all tasks."""
        if PYSIDE_AVAILABLE:
            self.task_list.clear()
            self.tasks.clear()
            self.progress_bar.setVisible(False)
