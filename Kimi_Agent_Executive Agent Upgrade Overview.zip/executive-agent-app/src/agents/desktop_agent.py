"""Desktop agent for application control tasks."""

from pathlib import Path
from typing import Any, Optional

from ..tools_ext.desktop_tools import DesktopTools
from ..tools_ext.vision_tools import VisionTools


class DesktopAgent:
    """Specialist agent for desktop application control."""

    def __init__(
        self,
        desktop_tools: Optional[DesktopTools] = None,
        vision_tools: Optional[VisionTools] = None,
    ):
        """Initialize desktop agent.

        Args:
            desktop_tools: DesktopTools instance
            vision_tools: VisionTools instance
        """
        self.desktop = desktop_tools or DesktopTools()
        self.vision = vision_tools or VisionTools()

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load desktop prompt from file."""
        prompt_path = Path("src/prompts/desktop.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are a desktop application control specialist agent."

    def launch_target_app(self, app_name: str, args: Optional[list[str]] = None) -> dict[str, Any]:
        """Launch a target application.

        Args:
            app_name: Application name or executable
            args: Optional arguments

        Returns:
            Launch result
        """
        return self.desktop.launch_application(app_name, args)

    def focus_window(self, title: str) -> dict[str, Any]:
        """Focus a window.

        Args:
            title: Window title

        Returns:
            Focus result
        """
        return self.desktop.focus_window(title)

    def inspect_window_state(self) -> dict[str, Any]:
        """Inspect the current window state.

        Returns:
            Window state
        """
        return self.desktop.list_controls()

    def perform_ui_step(
        self,
        action: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Perform a UI action step.

        Args:
            action: Action type
            params: Action parameters

        Returns:
            Action result
        """
        if action == "click":
            return self.desktop.click_control(
                name=params.get("name"),
                automation_id=params.get("automation_id"),
            )
        elif action == "type":
            return self.desktop.type_into_control(
                text=params.get("text", ""),
                name=params.get("name"),
                automation_id=params.get("automation_id"),
            )
        elif action == "hotkey":
            return self.desktop.send_hotkey(params.get("keys", []))
        elif action == "keys":
            return self.desktop.send_keys(params.get("text", ""))
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def verify_ui_state(self, expected_state: dict[str, Any]) -> dict[str, Any]:
        """Verify the UI is in expected state.

        Args:
            expected_state: Expected state properties

        Returns:
            Verification result
        """
        # Get current window title
        title_result = self.desktop.get_window_title()

        if not title_result.get("success"):
            return title_result

        current_title = title_result.get("title", "")
        expected_title = expected_state.get("window_title")

        if expected_title and expected_title.lower() not in current_title.lower():
            return {
                "success": False,
                "error": f"Window title mismatch. Expected: {expected_title}, Got: {current_title}",
            }

        return {
            "success": True,
            "verified": True,
            "current_title": current_title,
        }

    def capture_and_verify(
        self,
        reference_image: Optional[str] = None,
    ) -> dict[str, Any]:
        """Capture screen and optionally compare with reference.

        Args:
            reference_image: Optional reference image path

        Returns:
            Capture/verification result
        """
        capture_result = self.desktop.capture_window()

        if not capture_result.get("success"):
            return capture_result

        if reference_image:
            # Compare with reference
            compare_result = self.vision.compare_screens(
                reference_image,
                capture_result.get("path", ""),
            )
            return compare_result

        return capture_result

    def execute_ui_sequence(self, sequence: list[dict[str, Any]]) -> dict[str, Any]:
        """Execute a sequence of UI actions.

        Args:
            sequence: List of UI actions

        Returns:
            Execution result
        """
        results = []

        for step in sequence:
            action = step.get("action")
            params = step.get("params", {})

            result = self.perform_ui_step(action, params)
            results.append({"step": step, "result": result})

            if not result.get("success"):
                return {
                    "success": False,
                    "error": f"Step failed: {result.get('error')}",
                    "results": results,
                }

        return {
            "success": True,
            "steps_completed": len(results),
            "results": results,
        }

    def handle_desktop_task(self, action: str, context: dict[str, Any]) -> dict[str, Any]:
        """Handle a desktop task.

        Args:
            action: Action to perform
            context: Task context

        Returns:
            Task result
        """
        handlers = {
            "launch_app": lambda: self.launch_target_app(
                context.get("app_name", ""),
                context.get("args"),
            ),
            "focus_window": lambda: self.focus_window(context.get("title", "")),
            "inspect_ui": self.inspect_window_state,
            "perform_ui_step": lambda: self.perform_ui_step(
                context.get("ui_action", ""),
                context.get("params", {}),
            ),
            "verify_ui_state": lambda: self.verify_ui_state(context.get("expected_state", {})),
            "capture_and_verify": lambda: self.capture_and_verify(
                context.get("reference_image")
            ),
            "execute_ui_sequence": lambda: self.execute_ui_sequence(
                context.get("sequence", [])
            ),
        }

        handler = handlers.get(action)
        if handler:
            return handler()

        return {"success": False, "error": f"Unknown action: {action}"}
