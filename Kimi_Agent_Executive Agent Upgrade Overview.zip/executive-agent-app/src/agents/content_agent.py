"""Content agent for content creation tasks."""

from pathlib import Path
from typing import Any, Optional

from ..memory.profile_store import ProfileStore


class ContentAgent:
    """Specialist agent for content creation tasks."""

    def __init__(self, profile_store: Optional[ProfileStore] = None):
        """Initialize content agent.

        Args:
            profile_store: ProfileStore instance
        """
        self.profile = profile_store

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load content prompt from file."""
        prompt_path = Path("src/prompts/content.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are a content creation specialist agent."

    def _get_writing_style(self) -> str:
        """Get user's writing style preference."""
        if self.profile:
            return self.profile.get_profile_value("writing_style", "professional")
        return "professional"

    def create_youtube_description(
        self,
        video_title: str,
        video_content: str,
        keywords: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Create YouTube video description.

        Args:
            video_title: Video title
            video_content: Video content summary
            keywords: Optional SEO keywords

        Returns:
            Generated description
        """
        writing_style = self._get_writing_style()

        # This is a placeholder - in practice, this would use an LLM
        description = f"""{video_title}

{video_content}

📝 About this video:
This video provides valuable insights and information. 

👍 If you found this helpful, please like and subscribe!

📌 Timestamps:
00:00 Introduction
01:00 Main content

{"#" + " #".join(keywords) if keywords else ""}

---
Written in {writing_style} style.
"""

        return {
            "success": True,
            "description": description,
            "title": video_title,
            "style": writing_style,
        }

    def create_tiktok_caption(
        self,
        video_topic: str,
        hook: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create TikTok caption.

        Args:
            video_topic: Video topic
            hook: Optional hook text

        Returns:
            Generated caption
        """
        writing_style = self._get_writing_style()

        caption = f"""{hook or "POV:"} {video_topic} ✨

#fyp #viral #trending #{video_topic.replace(" ", "").lower()}

Follow for more! 👆
"""

        return {
            "success": True,
            "caption": caption,
            "topic": video_topic,
            "style": writing_style,
        }

    def create_product_description(
        self,
        product_name: str,
        features: list[str],
        target_audience: str,
    ) -> dict[str, Any]:
        """Create product description.

        Args:
            product_name: Product name
            features: Product features
            target_audience: Target audience

        Returns:
            Generated description
        """
        writing_style = self._get_writing_style()

        features_text = "\n".join(f"✓ {feature}" for feature in features)

        description = f"""Introducing {product_name}

Perfect for {target_audience}!

Key Features:
{features_text}

Experience the difference with {product_name}. Designed with you in mind.

Order now and transform your experience!
"""

        return {
            "success": True,
            "description": description,
            "product": product_name,
            "style": writing_style,
        }

    def create_marketing_copy(
        self,
        campaign_goal: str,
        call_to_action: str,
        tone: str = "professional",
    ) -> dict[str, Any]:
        """Create marketing copy.

        Args:
            campaign_goal: Campaign goal
            call_to_action: Call to action text
            tone: Copy tone

        Returns:
            Generated copy
        """
        copy = f"""🚀 {campaign_goal}

Don't miss out on this opportunity!

{call_to_action}

Limited time offer. Act now!
"""

        return {
            "success": True,
            "copy": copy,
            "goal": campaign_goal,
            "tone": tone,
        }

    def create_outreach_email(
        self,
        recipient_name: str,
        purpose: str,
        key_points: list[str],
    ) -> dict[str, Any]:
        """Create outreach email.

        Args:
            recipient_name: Recipient name
            purpose: Email purpose
            key_points: Key message points

        Returns:
            Generated email
        """
        writing_style = self._get_writing_style()
        sender_name = self.profile.get_profile_value("name", "") if self.profile else ""

        points_text = "\n".join(f"• {point}" for point in key_points)

        email = f"""Subject: {purpose}

Hi {recipient_name},

I hope this email finds you well.

{purpose}

Key highlights:
{points_text}

I'd love to discuss this further. Are you available for a brief call this week?

Best regards,
{sender_name}
"""

        return {
            "success": True,
            "email": email,
            "recipient": recipient_name,
            "style": writing_style,
        }

    def create_blog_post(
        self,
        title: str,
        outline: list[str],
        word_count: int = 500,
    ) -> dict[str, Any]:
        """Create blog post.

        Args:
            title: Blog title
            outline: Content outline
            word_count: Target word count

        Returns:
            Generated blog post
        """
        writing_style = self._get_writing_style()

        # This is a simplified placeholder
        sections = "\n\n".join(f"## {section}\n\n[Content for {section}]" for section in outline)

        blog = f"""# {title}

{sections}

---

*Written in {writing_style} style*
"""

        return {
            "success": True,
            "blog_post": blog,
            "title": title,
            "target_words": word_count,
            "style": writing_style,
        }

    def create_social_post(
        self,
        platform: str,
        message: str,
        include_hashtags: bool = True,
    ) -> dict[str, Any]:
        """Create social media post.

        Args:
            platform: Social platform
            message: Core message
            include_hashtags: Whether to include hashtags

        Returns:
            Generated post
        """
        writing_style = self._get_writing_style()

        hashtags = ""
        if include_hashtags:
            words = message.lower().split()
            hashtags = " ".join(f"#{word}" for word in words[:3] if len(word) > 3)

        post = f"""{message}

{hashtags}
"""

        # Platform-specific formatting
        if platform == "twitter":
            post = post[:280]  # Twitter character limit

        return {
            "success": True,
            "post": post,
            "platform": platform,
            "style": writing_style,
        }

    def handle_content_task(self, action: str, context: dict[str, Any]) -> dict[str, Any]:
        """Handle a content task.

        Args:
            action: Action to perform
            context: Task context

        Returns:
            Task result
        """
        handlers = {
            "youtube_description": lambda: self.create_youtube_description(
                context.get("video_title", ""),
                context.get("video_content", ""),
                context.get("keywords"),
            ),
            "tiktok_caption": lambda: self.create_tiktok_caption(
                context.get("video_topic", ""),
                context.get("hook"),
            ),
            "product_description": lambda: self.create_product_description(
                context.get("product_name", ""),
                context.get("features", []),
                context.get("target_audience", ""),
            ),
            "marketing_copy": lambda: self.create_marketing_copy(
                context.get("campaign_goal", ""),
                context.get("call_to_action", ""),
                context.get("tone", "professional"),
            ),
            "outreach_email": lambda: self.create_outreach_email(
                context.get("recipient_name", ""),
                context.get("purpose", ""),
                context.get("key_points", []),
            ),
            "blog_post": lambda: self.create_blog_post(
                context.get("title", ""),
                context.get("outline", []),
                context.get("word_count", 500),
            ),
            "social_post": lambda: self.create_social_post(
                context.get("platform", ""),
                context.get("message", ""),
                context.get("include_hashtags", True),
            ),
        }

        handler = handlers.get(action)
        if handler:
            return handler()

        return {"success": False, "error": f"Unknown action: {action}"}
