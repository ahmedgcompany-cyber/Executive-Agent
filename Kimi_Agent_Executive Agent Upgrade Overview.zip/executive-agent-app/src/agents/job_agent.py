"""Job agent for job application tasks."""

from pathlib import Path
from typing import Any, Optional

from ..memory.profile_store import ProfileStore
from ..tools_ext.browser_tools import BrowserTools
from ..tools_ext.form_tools import FormTools


class JobAgent:
    """Specialist agent for job applications."""

    def __init__(
        self,
        profile_store: ProfileStore,
        browser_tools: Optional[BrowserTools] = None,
    ):
        """Initialize job agent.

        Args:
            profile_store: ProfileStore instance
            browser_tools: Optional BrowserTools instance
        """
        self.profile = profile_store
        self.browser = browser_tools or BrowserTools()
        self.form = FormTools(self.browser)

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load job prompt from file."""
        prompt_path = Path("src/prompts/jobs.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are a job application specialist agent."

    def match_job(self, job_description: str) -> dict[str, Any]:
        """Match job requirements to user profile.

        Args:
            job_description: Job description text

        Returns:
            Match analysis
        """
        job_lower = job_description.lower()

        # Get user skills and experience
        user_skills = self.profile.get_profile_value("skills", [])
        job_titles = self.profile.get_profile_value("job_titles", [])
        years_exp = self.profile.get_job_answer("years_of_experience", "")

        # Simple keyword matching
        matched_skills = []
        for skill in user_skills:
            if skill.lower() in job_lower:
                matched_skills.append(skill)

        # Calculate match score
        skill_match = len(matched_skills) / max(len(user_skills), 1) * 100

        return {
            "success": True,
            "matched_skills": matched_skills,
            "skill_match_percent": round(skill_match, 1),
            "user_job_titles": job_titles,
            "years_experience": years_exp,
            "recommendation": "apply" if skill_match > 50 else "review",
        }

    def prepare_application_payload(self, job_title: str) -> dict[str, Any]:
        """Prepare application materials.

        Args:
            job_title: Job title

        Returns:
            Application payload
        """
        # Get default resume
        resume_path = self.profile.get_default_resume()

        # Get relevant answers
        answers = {
            "work_authorization": self.profile.get_job_answer("work_authorization"),
            "notice_period": self.profile.get_job_answer("notice_period"),
            "salary_expectation": self.profile.get_job_answer("salary_expectation"),
            "years_of_experience": self.profile.get_job_answer("years_of_experience"),
            "why_this_role": self.profile.get_job_answer("why_this_role"),
            "about_you": self.profile.get_job_answer("about_you"),
        }

        # Get contact info
        contact = {
            "name": self.profile.get_profile_value("name", ""),
            "email": self.profile.get_primary_email(),
            "phone": self.profile.get_primary_phone(),
            "linkedin": self.profile.get_profile_value("linkedin", ""),
        }

        return {
            "success": True,
            "resume_path": resume_path,
            "answers": answers,
            "contact": contact,
            "job_title": job_title,
        }

    async def fill_application(
        self,
        job_url: str,
        custom_answers: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """Fill a job application form.

        Args:
            job_url: Job application URL
            custom_answers: Optional custom answers

        Returns:
            Fill result
        """
        # Open the job page
        open_result = await self.browser.browser_open(job_url)
        if not open_result.get("success"):
            return open_result

        # Analyze form
        form_analysis = await self.form.analyze_form_fields()
        if not form_analysis.get("success"):
            return form_analysis

        # Prepare answers
        profile = self.profile.user_profile
        job_answers = self.profile.job_answers

        if custom_answers:
            job_answers.update(custom_answers)

        # Fill form
        fill_result = await self.form.fill_form_from_profile(profile, job_answers)

        return {
            "success": fill_result.get("success"),
            "filled_fields": fill_result.get("filled_count", 0),
            "results": fill_result.get("results", []),
        }

    def select_resume_variant(self, job_type: str) -> dict[str, Any]:
        """Select the best resume variant for a job type.

        Args:
            job_type: Type of job

        Returns:
            Selected resume
        """
        # Get default resume
        default_resume = self.profile.get_default_resume()

        # In practice, you'd have multiple resume variants
        # and select based on job type

        return {
            "success": True,
            "selected_resume": default_resume,
            "job_type": job_type,
            "note": "Resume selection would use job-type matching",
        }

    def generate_cover_letter(
        self,
        company: str,
        position: str,
        job_description: str,
    ) -> dict[str, Any]:
        """Generate a cover letter.

        Args:
            company: Company name
            position: Position title
            job_description: Job description

        Returns:
            Generated cover letter
        """
        # This is a placeholder - in practice, this would use an LLM
        # to generate a personalized cover letter

        name = self.profile.get_profile_value("name", "")

        cover_letter = f"""Dear Hiring Manager,

I am writing to express my interest in the {position} position at {company}.

{self.profile.get_job_answer("about_you", "")}

{self.profile.get_job_answer("why_this_role", "")}

My experience includes:
{chr(10).join(f"- {skill}" for skill in self.profile.get_profile_value("skills", []))}

I am excited about the opportunity to contribute to your team.

Sincerely,
{name}
"""

        return {
            "success": True,
            "cover_letter": cover_letter,
            "company": company,
            "position": position,
        }

    def handle_job_task(self, action: str, context: dict[str, Any]) -> dict[str, Any]:
        """Handle a job task.

        Args:
            action: Action to perform
            context: Task context

        Returns:
            Task result
        """
        handlers = {
            "match_job": lambda: self.match_job(context.get("job_description", "")),
            "prepare_payload": lambda: self.prepare_application_payload(
                context.get("job_title", "")
            ),
            "select_resume": lambda: self.select_resume_variant(context.get("job_type", "")),
            "generate_cover_letter": lambda: self.generate_cover_letter(
                context.get("company", ""),
                context.get("position", ""),
                context.get("job_description", ""),
            ),
        }

        handler = handlers.get(action)
        if handler:
            return handler()

        return {"success": False, "error": f"Unknown action: {action}"}
