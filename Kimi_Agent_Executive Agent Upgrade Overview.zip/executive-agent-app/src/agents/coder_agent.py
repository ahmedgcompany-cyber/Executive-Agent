"""Coder agent for software development tasks."""

import subprocess
from pathlib import Path
from typing import Any, Optional


class CoderAgent:
    """Specialist agent for coding and development tasks."""

    def __init__(self, workspace_dir: str = "."):
        """Initialize coder agent.

        Args:
            workspace_dir: Workspace directory
        """
        self.workspace_dir = Path(workspace_dir)

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load coder prompt from file."""
        prompt_path = Path("src/prompts/coder.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are a coding specialist agent."

    def inspect_project(self, path: Optional[str] = None) -> dict[str, Any]:
        """Inspect project structure.

        Args:
            path: Optional path to inspect

        Returns:
            Project structure
        """
        target_path = Path(path) if path else self.workspace_dir

        try:
            files = []
            dirs = []

            for item in target_path.iterdir():
                if item.is_file():
                    files.append({
                        "name": item.name,
                        "size": item.stat().st_size,
                        "extension": item.suffix,
                    })
                elif item.is_dir():
                    dirs.append(item.name)

            # Detect project type
            project_type = self._detect_project_type(files)

            return {
                "success": True,
                "path": str(target_path),
                "files": files,
                "directories": dirs,
                "project_type": project_type,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _detect_project_type(self, files: list[dict[str, Any]]) -> str:
        """Detect project type from files.

        Args:
            files: List of file info

        Returns:
            Project type
        """
        filenames = [f["name"] for f in files]

        if "package.json" in filenames:
            return "nodejs"
        elif "requirements.txt" in filenames or "pyproject.toml" in filenames:
            return "python"
        elif "Cargo.toml" in filenames:
            return "rust"
        elif "pom.xml" in filenames or "build.gradle" in filenames:
            return "java"
        elif "go.mod" in filenames:
            return "go"
        elif "CMakeLists.txt" in filenames:
            return "cpp"
        elif any(f.endswith(".sln") for f in filenames):
            return "dotnet"
        else:
            return "unknown"

    def generate_code(
        self,
        description: str,
        output_path: str,
        language: Optional[str] = None,
    ) -> dict[str, Any]:
        """Generate code based on description.

        Args:
            description: Code description
            output_path: Output file path
            language: Programming language

        Returns:
            Generation result
        """
        try:
            output_file = Path(output_path)

            # Determine language from extension if not provided
            if not language:
                language = output_file.suffix.lstrip(".")

            # This is a placeholder - in practice, this would use an LLM
            # to generate the actual code
            code = f"# Generated code for: {description}\n"
            code += f"# Language: {language}\n\n"
            code += "# TODO: Implement the described functionality\n"

            # Write file
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(code, encoding="utf-8")

            return {
                "success": True,
                "path": str(output_file),
                "language": language,
                "lines": len(code.splitlines()),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def read_file(self, path: str) -> dict[str, Any]:
        """Read a file.

        Args:
            path: File path

        Returns:
            File content
        """
        try:
            file_path = Path(path)
            if not file_path.exists():
                return {"success": False, "error": f"File not found: {path}"}

            content = file_path.read_text(encoding="utf-8")

            return {
                "success": True,
                "path": str(file_path),
                "content": content,
                "lines": len(content.splitlines()),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_file(self, path: str, content: str) -> dict[str, Any]:
        """Write a file.

        Args:
            path: File path
            content: File content

        Returns:
            Write result
        """
        try:
            file_path = Path(path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")

            return {
                "success": True,
                "path": str(file_path),
                "lines": len(content.splitlines()),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def edit_file(
        self,
        path: str,
        old_text: str,
        new_text: str,
    ) -> dict[str, Any]:
        """Edit a file by replacing text.

        Args:
            path: File path
            old_text: Text to replace
            new_text: Replacement text

        Returns:
            Edit result
        """
        try:
            file_path = Path(path)
            if not file_path.exists():
                return {"success": False, "error": f"File not found: {path}"}

            content = file_path.read_text(encoding="utf-8")

            if old_text not in content:
                return {"success": False, "error": "Old text not found in file"}

            new_content = content.replace(old_text, new_text)
            file_path.write_text(new_content, encoding="utf-8")

            return {
                "success": True,
                "path": str(file_path),
                "replacements": content.count(old_text),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_build(self, build_command: Optional[str] = None) -> dict[str, Any]:
        """Run build command.

        Args:
            build_command: Optional build command

        Returns:
            Build result
        """
        try:
            # Detect build command if not provided
            if not build_command:
                project_type = self.inspect_project().get("project_type", "unknown")
                build_commands = {
                    "nodejs": "npm run build",
                    "python": "python -m build",
                    "rust": "cargo build",
                    "java": "mvn build",
                    "go": "go build",
                }
                build_command = build_commands.get(project_type)

            if not build_command:
                return {
                    "success": False,
                    "error": "No build command specified or detected",
                }

            result = subprocess.run(
                build_command.split(),
                capture_output=True,
                text=True,
                cwd=self.workspace_dir,
            )

            return {
                "success": result.returncode == 0,
                "command": build_command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_tests(self, test_command: Optional[str] = None) -> dict[str, Any]:
        """Run tests.

        Args:
            test_command: Optional test command

        Returns:
            Test result
        """
        try:
            # Detect test command if not provided
            if not test_command:
                project_type = self.inspect_project().get("project_type", "unknown")
                test_commands = {
                    "nodejs": "npm test",
                    "python": "pytest",
                    "rust": "cargo test",
                    "java": "mvn test",
                    "go": "go test",
                }
                test_command = test_commands.get(project_type)

            if not test_command:
                return {
                    "success": False,
                    "error": "No test command specified or detected",
                }

            result = subprocess.run(
                test_command.split(),
                capture_output=True,
                text=True,
                cwd=self.workspace_dir,
            )

            return {
                "success": result.returncode == 0,
                "command": test_command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def repair_build(self, error_output: str) -> dict[str, Any]:
        """Attempt to repair build errors.

        Args:
            error_output: Build error output

        Returns:
            Repair result
        """
        # This is a placeholder - in practice, this would analyze errors
        # and attempt automated fixes

        return {
            "success": True,
            "message": "Build repair analysis",
            "error_output": error_output,
            "note": "Automated repair would be implemented with error pattern matching",
        }

    def package_output(
        self,
        output_dir: str,
        format: str = "zip",
    ) -> dict[str, Any]:
        """Package output files.

        Args:
            output_dir: Output directory
            format: Package format

        Returns:
            Package result
        """
        try:
            import shutil

            output_path = Path(output_dir)
            if not output_path.exists():
                return {"success": False, "error": f"Output directory not found: {output_dir}"}

            package_name = f"{output_path.name}.{format}"
            package_path = output_path.parent / package_name

            if format == "zip":
                shutil.make_archive(
                    str(package_path.with_suffix("")),
                    "zip",
                    output_path,
                )
            elif format == "tar":
                shutil.make_archive(
                    str(package_path.with_suffix("")),
                    "tar",
                    output_path,
                )
            else:
                return {"success": False, "error": f"Unsupported format: {format}"}

            return {
                "success": True,
                "package_path": str(package_path),
                "format": format,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def handle_code_task(self, action: str, context: dict[str, Any]) -> dict[str, Any]:
        """Handle a code task.

        Args:
            action: Action to perform
            context: Task context

        Returns:
            Task result
        """
        handlers = {
            "inspect_project": lambda: self.inspect_project(context.get("path")),
            "generate_code": lambda: self.generate_code(
                context.get("description", ""),
                context.get("output_path", ""),
                context.get("language"),
            ),
            "read_file": lambda: self.read_file(context.get("path", "")),
            "write_file": lambda: self.write_file(
                context.get("path", ""),
                context.get("content", ""),
            ),
            "edit_file": lambda: self.edit_file(
                context.get("path", ""),
                context.get("old_text", ""),
                context.get("new_text", ""),
            ),
            "run_build": lambda: self.run_build(context.get("build_command")),
            "run_tests": lambda: self.run_tests(context.get("test_command")),
            "repair_build": lambda: self.repair_build(context.get("error_output", "")),
            "package_output": lambda: self.package_output(
                context.get("output_dir", ""),
                context.get("format", "zip"),
            ),
        }

        handler = handlers.get(action)
        if handler:
            return handler()

        return {"success": False, "error": f"Unknown action: {action}"}
