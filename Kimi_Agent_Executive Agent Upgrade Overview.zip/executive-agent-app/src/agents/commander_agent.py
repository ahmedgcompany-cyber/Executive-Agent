"""Commander agent for task routing and coordination."""

from pathlib import Path
from typing import Any, Optional


class CommanderAgent:
    """Main commander agent that routes tasks to specialist agents."""

    def __init__(
        self,
        coder_agent: Optional[Any] = None,
        browser_agent: Optional[Any] = None,
        desktop_agent: Optional[Any] = None,
        job_agent: Optional[Any] = None,
        sales_agent: Optional[Any] = None,
        content_agent: Optional[Any] = None,
        skill_agent: Optional[Any] = None,
        memory_agent: Optional[Any] = None,
    ):
        """Initialize commander agent.

        Args:
            coder_agent: Coder agent instance
            browser_agent: Browser agent instance
            desktop_agent: Desktop agent instance
            job_agent: Job agent instance
            sales_agent: Sales agent instance
            content_agent: Content agent instance
            skill_agent: Skill agent instance
            memory_agent: Memory agent instance
        """
        self.agents = {
            "coder": coder_agent,
            "browser": browser_agent,
            "desktop": desktop_agent,
            "job": job_agent,
            "sales": sales_agent,
            "content": content_agent,
            "skill": skill_agent,
            "memory": memory_agent,
        }

        self.current_plan: list[dict[str, Any]] = []
        self.current_step: int = 0
        self.task_history: list[dict[str, Any]] = []

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load commander prompt from file."""
        prompt_path = Path("src/prompts/commander.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are the commander agent. Route tasks to appropriate specialist agents."

    def analyze_goal(self, goal: str) -> dict[str, Any]:
        """Analyze a user goal and determine the approach.

        Args:
            goal: User's goal

        Returns:
            Analysis result
        """
        # Simple keyword-based analysis
        goal_lower = goal.lower()

        indicators = {
            "coder": ["code", "program", "develop", "build", "create app", "write script", "debug", "fix"],
            "browser": ["website", "web", "browser", "form", "apply", "login", "search online", "fill"],
            "desktop": ["open app", "launch", "photoshop", "illustrator", "blender", "desktop", "window"],
            "job": ["job", "apply", "resume", "cover letter", "interview", "career", "position"],
            "sales": ["lead", "prospect", "market research", "competitor", "outreach", "sales"],
            "content": ["write", "content", "blog", "social media", "youtube", "tiktok", "description"],
            "skill": ["install skill", "add skill", "skill", "capability", "extension"],
            "memory": ["remember", "save", "profile", "my information", "store"],
        }

        scores = {agent: 0 for agent in indicators.keys()}

        for agent, keywords in indicators.items():
            for keyword in keywords:
                if keyword in goal_lower:
                    scores[agent] += 1

        # Find best match
        best_agent = max(scores, key=scores.get)
        best_score = scores[best_agent]

        if best_score == 0:
            # Default to coder for ambiguous tasks
            best_agent = "coder"

        return {
            "success": True,
            "goal": goal,
            "suggested_agent": best_agent,
            "confidence": min(best_score / 3, 1.0),
            "all_scores": scores,
        }

    def plan_steps(self, goal: str) -> dict[str, Any]:
        """Create a plan to achieve the goal.

        Args:
            goal: User's goal

        Returns:
            Plan with steps
        """
        analysis = self.analyze_goal(goal)
        primary_agent = analysis.get("suggested_agent", "coder")

        # Create a simple plan based on the agent type
        plans = {
            "coder": [
                {"agent": "coder", "action": "inspect_project", "description": "Inspect project structure"},
                {"agent": "coder", "action": "generate_code", "description": "Generate or modify code"},
                {"agent": "coder", "action": "verify", "description": "Verify the implementation"},
            ],
            "browser": [
                {"agent": "browser", "action": "open_site", "description": "Open target website"},
                {"agent": "browser", "action": "analyze_form", "description": "Analyze page/form structure"},
                {"agent": "browser", "action": "execute_task", "description": "Execute browser task"},
                {"agent": "browser", "action": "verify", "description": "Verify completion"},
            ],
            "desktop": [
                {"agent": "desktop", "action": "launch_app", "description": "Launch target application"},
                {"agent": "desktop", "action": "inspect_ui", "description": "Inspect UI elements"},
                {"agent": "desktop", "action": "execute_action", "description": "Execute UI action"},
                {"agent": "desktop", "action": "verify", "description": "Verify result"},
            ],
            "job": [
                {"agent": "job", "action": "match_job", "description": "Analyze job requirements"},
                {"agent": "job", "action": "prepare_payload", "description": "Prepare application materials"},
                {"agent": "job", "action": "fill_application", "description": "Fill application form"},
                {"agent": "job", "action": "submit", "description": "Submit application"},
            ],
            "sales": [
                {"agent": "sales", "action": "research", "description": "Research market/leads"},
                {"agent": "sales", "action": "structure", "description": "Structure findings"},
                {"agent": "sales", "action": "draft", "description": "Draft outreach materials"},
            ],
            "content": [
                {"agent": "content", "action": "analyze", "description": "Analyze content requirements"},
                {"agent": "content", "action": "create", "description": "Create content"},
                {"agent": "content", "action": "review", "description": "Review and refine"},
            ],
        }

        self.current_plan = plans.get(primary_agent, plans["coder"])
        self.current_step = 0

        return {
            "success": True,
            "goal": goal,
            "primary_agent": primary_agent,
            "steps": self.current_plan,
            "total_steps": len(self.current_plan),
        }

    def route_step(self, step: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Route a step to the appropriate agent.

        Args:
            step: Step to execute
            context: Execution context

        Returns:
            Execution result
        """
        agent_name = step.get("agent", "coder")
        action = step.get("action", "")

        agent = self.agents.get(agent_name)

        if not agent:
            return {
                "success": False,
                "error": f"Agent not available: {agent_name}",
            }

        # Route to agent's handler
        if agent_name == "coder" and hasattr(agent, "handle_code_task"):
            return agent.handle_code_task(action, context)
        elif agent_name == "browser" and hasattr(agent, "handle_browser_task"):
            return agent.handle_browser_task(action, context)
        elif agent_name == "desktop" and hasattr(agent, "handle_desktop_task"):
            return agent.handle_desktop_task(action, context)
        elif agent_name == "job" and hasattr(agent, "handle_job_task"):
            return agent.handle_job_task(action, context)
        elif agent_name == "sales" and hasattr(agent, "handle_sales_task"):
            return agent.handle_sales_task(action, context)
        elif agent_name == "content" and hasattr(agent, "handle_content_task"):
            return agent.handle_content_task(action, context)
        elif agent_name == "skill" and hasattr(agent, "handle_skill_task"):
            return agent.handle_skill_task(action, context)
        elif agent_name == "memory" and hasattr(agent, "handle_memory_task"):
            return agent.handle_memory_task(action, context)

        return {
            "success": False,
            "error": f"No handler for agent: {agent_name}",
        }

    def select_agent_for_step(self, step_description: str) -> str:
        """Select the best agent for a step.

        Args:
            step_description: Step description

        Returns:
            Agent name
        """
        analysis = self.analyze_goal(step_description)
        return analysis.get("suggested_agent", "coder")

    def summarize_progress(self) -> dict[str, Any]:
        """Summarize current task progress.

        Returns:
            Progress summary
        """
        completed_steps = self.current_step
        total_steps = len(self.current_plan)

        return {
            "success": True,
            "completed_steps": completed_steps,
            "total_steps": total_steps,
            "percent_complete": (completed_steps / total_steps * 100) if total_steps > 0 else 0,
            "current_step": self.current_plan[completed_steps] if completed_steps < total_steps else None,
            "history": self.task_history,
        }

    def promote_workflow_to_skill(self, workflow_name: str) -> dict[str, Any]:
        """Promote a successful workflow to a skill.

        Args:
            workflow_name: Workflow name

        Returns:
            Promotion result
        """
        skill_agent = self.agents.get("skill")

        if not skill_agent:
            return {
                "success": False,
                "error": "Skill agent not available",
            }

        # This would integrate with skill agent
        return {
            "success": True,
            "workflow": workflow_name,
            "message": "Workflow promoted to skill",
        }

    def execute_goal(self, goal: str, context: dict[str, Any]) -> dict[str, Any]:
        """Execute a complete goal.

        Args:
            goal: User's goal
            context: Execution context

        Returns:
            Execution result
        """
        # Create plan
        plan = self.plan_steps(goal)

        if not plan.get("success"):
            return plan

        results = []

        # Execute each step
        for i, step in enumerate(self.current_plan):
            self.current_step = i

            result = self.route_step(step, context)
            results.append({
                "step": step,
                "result": result,
            })

            # Record in history
            self.task_history.append({
                "step": step,
                "result": result,
            })

            # Stop on failure
            if not result.get("success"):
                return {
                    "success": False,
                    "error": f"Step {i+1} failed: {result.get('error', 'Unknown error')}",
                    "results": results,
                }

        return {
            "success": True,
            "goal": goal,
            "steps_completed": len(results),
            "results": results,
        }
