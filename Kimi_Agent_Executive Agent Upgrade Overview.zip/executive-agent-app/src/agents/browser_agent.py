"""Browser agent for web automation tasks."""

from pathlib import Path
from typing import Any, Optional

from ..tools_ext.browser_tools import BrowserTools
from ..tools_ext.form_tools import FormTools
from ..memory.profile_store import ProfileStore


class BrowserAgent:
    """Specialist agent for browser automation and form filling."""

    def __init__(
        self,
        browser_tools: Optional[BrowserTools] = None,
        profile_store: Optional[ProfileStore] = None,
    ):
        """Initialize browser agent.

        Args:
            browser_tools: BrowserTools instance
            profile_store: ProfileStore instance
        """
        self.browser = browser_tools or BrowserTools()
        self.form = FormTools(self.browser)
        self.profile = profile_store

        # Load prompt
        self.prompt = self._load_prompt()

    def _load_prompt(self) -> str:
        """Load browser prompt from file."""
        prompt_path = Path("src/prompts/browser.txt")
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "You are a browser automation specialist agent."

    async def open_site(self, url: str, headless: bool = False) -> dict[str, Any]:
        """Open a website.

        Args:
            url: URL to open
            headless: Run in headless mode

        Returns:
            Open result
        """
        return await self.browser.browser_open(url, headless)

    async def analyze_form(self) -> dict[str, Any]:
        """Analyze form on current page.

        Returns:
            Form analysis
        """
        return await self.form.analyze_form_fields()

    async def fill_form(
        self,
        field_values: Optional[dict[str, str]] = None,
        use_profile: bool = False,
    ) -> dict[str, Any]:
        """Fill form on current page.

        Args:
            field_values: Optional field values
            use_profile: Use profile data

        Returns:
            Fill result
        """
        if use_profile and self.profile:
            return await self.form.fill_form_from_profile(
                self.profile.user_profile,
                self.profile.job_answers,
            )
        elif field_values:
            return await self.form.fill_detected_form(field_values)
        else:
            return {"success": False, "error": "No field values or profile provided"}

    async def fill_detected_form(self, field_values: dict[str, str]) -> dict[str, Any]:
        """Fill form with provided values.

        Args:
            field_values: Field selector -> value mapping

        Returns:
            Fill result
        """
        return await self.form.fill_detected_form(field_values)

    async def select_dropdowns(self, selections: dict[str, str]) -> dict[str, Any]:
        """Select dropdown options.

        Args:
            selections: Selector -> value mapping

        Returns:
            Selection result
        """
        return await self.form.select_dropdowns(selections)

    async def upload_files(self, uploads: dict[str, str]) -> dict[str, Any]:
        """Upload files.

        Args:
            uploads: Selector -> file path mapping

        Returns:
            Upload result
        """
        return await self.form.upload_files(uploads)

    async def complete_multistep_flow(
        self,
        steps: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Complete a multi-step form flow.

        Args:
            steps: List of steps to execute

        Returns:
            Flow completion result
        """
        results = []

        for step in steps:
            action = step.get("action")
            params = step.get("params", {})

            if action == "click":
                result = await self.browser.browser_click(params.get("selector"))
            elif action == "type":
                result = await self.browser.browser_type(
                    params.get("selector"),
                    params.get("text"),
                )
            elif action == "select":
                result = await self.browser.browser_select(
                    params.get("selector"),
                    params.get("value"),
                )
            elif action == "upload":
                result = await self.browser.browser_upload(
                    params.get("selector"),
                    params.get("file_path"),
                )
            elif action == "wait":
                result = await self.browser.browser_wait_for(params.get("selector"))
            else:
                result = {"success": False, "error": f"Unknown action: {action}"}

            results.append({"step": step, "result": result})

            if not result.get("success"):
                return {
                    "success": False,
                    "error": f"Step failed: {result.get('error')}",
                    "results": results,
                }

        return {
            "success": True,
            "steps_completed": len(results),
            "results": results,
        }

    async def submit_form(self, submit_selector: str = "button[type='submit']") -> dict[str, Any]:
        """Submit the current form.

        Args:
            submit_selector: Submit button selector

        Returns:
            Submit result
        """
        return await self.browser.browser_click(submit_selector)

    async def take_screenshot(self, output_path: Optional[str] = None) -> dict[str, Any]:
        """Take a screenshot.

        Args:
            output_path: Optional output path

        Returns:
            Screenshot result
        """
        return await self.browser.browser_screenshot(output_path)

    async def navigate(self, url: str) -> dict[str, Any]:
        """Navigate to a URL.

        Args:
            url: URL to navigate to

        Returns:
            Navigation result
        """
        return await self.browser.browser_navigate(url)

    async def close_browser(self) -> dict[str, Any]:
        """Close the browser.

        Returns:
            Close result
        """
        return await self.browser.browser_close()

    async def handle_browser_task(self, action: str, context: dict[str, Any]) -> dict[str, Any]:
        """Handle a browser task.

        Args:
            action: Action to perform
            context: Task context

        Returns:
            Task result
        """
        handlers = {
            "open_site": lambda: self.open_site(
                context.get("url", ""),
                context.get("headless", False),
            ),
            "analyze_form": self.analyze_form,
            "fill_form": lambda: self.fill_form(
                context.get("field_values"),
                context.get("use_profile", False),
            ),
            "select_dropdowns": lambda: self.select_dropdowns(context.get("selections", {})),
            "upload_files": lambda: self.upload_files(context.get("uploads", {})),
            "complete_multistep_flow": lambda: self.complete_multistep_flow(
                context.get("steps", [])
            ),
            "submit_form": lambda: self.submit_form(context.get("submit_selector")),
            "take_screenshot": lambda: self.take_screenshot(context.get("output_path")),
            "navigate": lambda: self.navigate(context.get("url", "")),
            "close_browser": self.close_browser,
        }

        handler = handlers.get(action)
        if handler:
            return await handler()

        return {"success": False, "error": f"Unknown action: {action}"}
