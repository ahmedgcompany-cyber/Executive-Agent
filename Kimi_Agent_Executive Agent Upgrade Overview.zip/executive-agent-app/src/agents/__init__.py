"""Specialized agents for different task types."""

from .commander_agent import CommanderAgent
from .coder_agent import CoderAgent
from .browser_agent import BrowserAgent
from .desktop_agent import DesktopAgent
from .job_agent import JobAgent
from .sales_agent import SalesAgent
from .content_agent import ContentAgent
from .skill_agent import SkillAgent
from .memory_agent import MemoryAgent

__all__ = [
    "CommanderAgent",
    "CoderAgent",
    "BrowserAgent",
    "DesktopAgent",
    "JobAgent",
    "SalesAgent",
    "ContentAgent",
    "SkillAgent",
    "MemoryAgent",
]
