"""Browser automation tools using Playwright."""

import asyncio
from pathlib import Path
from typing import Any, Optional
from dataclasses import dataclass


@dataclass
class BrowserSession:
    """Browser session state."""
    playwright: Any = None
    browser: Any = None
    context: Any = None
    page: Any = None
    session_id: str = ""


class BrowserTools:
    """Web browser automation tools."""

    def __init__(self):
        """Initialize browser tools."""
        self.session: Optional[BrowserSession] = None
        self._playwright = None

    async def _ensure_playwright(self) -> Any:
        """Ensure playwright is imported."""
        if self._playwright is None:
            try:
                from playwright.async_api import async_playwright
                self._playwright = async_playwright
            except ImportError:
                raise ImportError("Playwright not installed. Run: pip install playwright")
        return self._playwright

    async def browser_open(self, url: str, headless: bool = False) -> dict[str, Any]:
        """Open a browser and navigate to URL.

        Args:
            url: URL to navigate to
            headless: Whether to run in headless mode

        Returns:
            Result with session info
        """
        try:
            playwright = await self._ensure_playwright()

            async with playwright() as p:
                browser = await p.chromium.launch(headless=headless)
                context = await browser.new_context(
                    viewport={"width": 1920, "height": 1080}
                )
                page = await context.new_page()
                await page.goto(url, wait_until="networkidle")

                self.session = BrowserSession(
                    playwright=p,
                    browser=browser,
                    context=context,
                    page=page,
                    session_id=f"session_{id(page)}"
                )

                return {
                    "success": True,
                    "session_id": self.session.session_id,
                    "url": page.url,
                    "title": await page.title(),
                }
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_click(self, selector: str) -> dict[str, Any]:
        """Click an element on the page.

        Args:
            selector: CSS selector for the element

        Returns:
            Click result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            await self.session.page.click(selector)
            return {"success": True, "selector": selector}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_type(self, selector: str, text: str, clear_first: bool = True) -> dict[str, Any]:
        """Type text into an input field.

        Args:
            selector: CSS selector for the input
            text: Text to type
            clear_first: Whether to clear field first

        Returns:
            Type result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            if clear_first:
                await self.session.page.fill(selector, "")
            await self.session.page.type(selector, text)
            return {"success": True, "selector": selector, "text": text}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_select(self, selector: str, value: str) -> dict[str, Any]:
        """Select an option from a dropdown.

        Args:
            selector: CSS selector for the select element
            value: Value to select

        Returns:
            Select result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            await self.session.page.select_option(selector, value)
            return {"success": True, "selector": selector, "value": value}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_upload(self, selector: str, file_path: str) -> dict[str, Any]:
        """Upload a file.

        Args:
            selector: CSS selector for the file input
            file_path: Path to the file to upload

        Returns:
            Upload result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            path = Path(file_path)
            if not path.exists():
                return {"success": False, "error": f"File not found: {file_path}"}

            input_element = await self.session.page.query_selector(selector)
            if not input_element:
                return {"success": False, "error": f"Element not found: {selector}"}

            await input_element.set_input_files(str(path.absolute()))
            return {"success": True, "selector": selector, "file": file_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_extract_fields(self) -> dict[str, Any]:
        """Extract form fields from the current page.

        Returns:
            List of form fields with their properties
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            fields = await self.session.page.evaluate("""
                () => {
                    const inputs = document.querySelectorAll('input, select, textarea');
                    return Array.from(inputs).map(input => ({
                        tag: input.tagName.toLowerCase(),
                        type: input.type || 'text',
                        name: input.name || '',
                        id: input.id || '',
                        placeholder: input.placeholder || '',
                        label: input.labels?.[0]?.textContent?.trim() || '',
                        required: input.required || false,
                        selector: input.id ? `#${input.id}` : 
                                  input.name ? `[name="${input.name}"]` : 
                                  input.className ? `.${input.className.split(' ')[0]}` : 
                                  input.tagName.toLowerCase()
                    }));
                }
            """)
            return {"success": True, "fields": fields}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_screenshot(self, output_path: Optional[str] = None) -> dict[str, Any]:
        """Take a screenshot of the current page.

        Args:
            output_path: Optional path to save screenshot

        Returns:
            Screenshot result with path
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            if output_path is None:
                output_path = f"screenshot_{self.session.session_id}.png"

            await self.session.page.screenshot(path=output_path, full_page=True)
            return {"success": True, "path": output_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_wait_for(self, selector: str, timeout: int = 30000) -> dict[str, Any]:
        """Wait for an element to appear.

        Args:
            selector: CSS selector to wait for
            timeout: Timeout in milliseconds

        Returns:
            Wait result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            await self.session.page.wait_for_selector(selector, timeout=timeout)
            return {"success": True, "selector": selector}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_get_html(self) -> dict[str, Any]:
        """Get the current page HTML.

        Returns:
            Page HTML content
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            html = await self.session.page.content()
            return {"success": True, "html": html}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_close(self) -> dict[str, Any]:
        """Close the browser session.

        Returns:
            Close result
        """
        if not self.session:
            return {"success": True, "message": "No session to close"}

        try:
            if self.session.browser:
                await self.session.browser.close()
            self.session = None
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_navigate(self, url: str) -> dict[str, Any]:
        """Navigate to a new URL in the current session.

        Args:
            url: URL to navigate to

        Returns:
            Navigation result
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            await self.session.page.goto(url, wait_until="networkidle")
            return {
                "success": True,
                "url": self.session.page.url,
                "title": await self.session.page.title(),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def browser_get_text(self, selector: str) -> dict[str, Any]:
        """Get text content of an element.

        Args:
            selector: CSS selector

        Returns:
            Text content
        """
        if not self.session or not self.session.page:
            return {"success": False, "error": "No active browser session"}

        try:
            element = await self.session.page.query_selector(selector)
            if not element:
                return {"success": False, "error": f"Element not found: {selector}"}
            text = await element.text_content()
            return {"success": True, "text": text or ""}
        except Exception as e:
            return {"success": False, "error": str(e)}
