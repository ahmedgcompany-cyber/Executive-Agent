"""Application adapters for creative and productivity software."""

from .photoshop_adapter import PhotoshopAdapter
from .illustrator_adapter import IllustratorAdapter
from .aftereffects_adapter import AfterEffectsAdapter
from .autocad_adapter import AutoCADAdapter
from .blender_adapter import BlenderAdapter
from .office_adapter import OfficeAdapter

__all__ = [
    "PhotoshopAdapter",
    "IllustratorAdapter",
    "AfterEffectsAdapter",
    "AutoCADAdapter",
    "BlenderAdapter",
    "OfficeAdapter",
]
