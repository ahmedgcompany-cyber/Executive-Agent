"""Main entry point for Executive Agent."""

import argparse
import asyncio
import sys
from pathlib import Path

from .memory.profile_store import ProfileStore
from .memory.workflow_store import WorkflowStore
from .tools_ext.browser_tools import BrowserTools
from .tools_ext.desktop_tools import DesktopTools
from .tools_ext.vision_tools import VisionTools
from .tools_ext.profile_tools import ProfileTools
from .tools_ext.workflow_tools import WorkflowTools
from .tools_ext.skill_tools import SkillTools
from .tools_ext.app_control_tools import AppControlTools
from .agents.commander_agent import CommanderAgent
from .agents.coder_agent import CoderAgent
from .agents.browser_agent import BrowserAgent
from .agents.desktop_agent import DesktopAgent
from .agents.job_agent import JobAgent
from .agents.sales_agent import SalesAgent
from .agents.content_agent import ContentAgent
from .agents.skill_agent import SkillAgent
from .agents.memory_agent import MemoryAgent


def load_app_config() -> dict:
    """Load application configuration.

    Returns:
        Configuration dictionary
    """
    import yaml

    config_path = Path("config/settings.yaml")
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


def build_runtime() -> dict:
    """Build the runtime context with all components.

    Returns:
        Runtime context dictionary
    """
    # Initialize memory stores
    profile_store = ProfileStore("profiles")
    workflow_store = WorkflowStore("workflows")

    # Initialize tools
    browser_tools = BrowserTools()
    desktop_tools = DesktopTools()
    vision_tools = VisionTools()
    profile_tools = ProfileTools(profile_store)
    workflow_tools = WorkflowTools(workflow_store)
    skill_tools = SkillTools("skills")
    app_control_tools = AppControlTools(desktop_tools)

    # Initialize agents
    coder_agent = CoderAgent()
    browser_agent = BrowserAgent(browser_tools, profile_store)
    desktop_agent = DesktopAgent(desktop_tools, vision_tools)
    job_agent = JobAgent(profile_store, browser_tools)
    sales_agent = SalesAgent()
    content_agent = ContentAgent(profile_store)
    skill_agent = SkillAgent(skill_tools)
    memory_agent = MemoryAgent(profile_store, workflow_store)

    # Initialize commander
    commander = CommanderAgent(
        coder_agent=coder_agent,
        browser_agent=browser_agent,
        desktop_agent=desktop_agent,
        job_agent=job_agent,
        sales_agent=sales_agent,
        content_agent=content_agent,
        skill_agent=skill_agent,
        memory_agent=memory_agent,
    )

    return {
        "profile_store": profile_store,
        "workflow_store": workflow_store,
        "browser_tools": browser_tools,
        "desktop_tools": desktop_tools,
        "vision_tools": vision_tools,
        "profile_tools": profile_tools,
        "workflow_tools": workflow_tools,
        "skill_tools": skill_tools,
        "app_control_tools": app_control_tools,
        "commander": commander,
        "coder_agent": coder_agent,
        "browser_agent": browser_agent,
        "desktop_agent": desktop_agent,
        "job_agent": job_agent,
        "sales_agent": sales_agent,
        "content_agent": content_agent,
        "skill_agent": skill_agent,
        "memory_agent": memory_agent,
    }


def print_banner():
    """Print the application banner."""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           Executive Agent - Local AI Operator               ║
║                                                              ║
║   Code • Browse • Automate • Control Desktop Apps           ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def start_cli_session():
    """Start an interactive CLI session."""
    from .cli import main as cli_main
    cli_main()


def start_gui():
    """Start the GUI application."""
    try:
        from .gui.app import main as gui_main
        return gui_main()
    except ImportError as e:
        print(f"Error starting GUI: {e}")
        print("Make sure PySide6 is installed: pip install pyside6")
        return 1


async def execute_single_goal(goal: str, runtime: dict) -> dict:
    """Execute a single goal and return the result.

    Args:
        goal: User's goal
        runtime: Runtime context

    Returns:
        Execution result
    """
    commander = runtime.get("commander")
    if not commander:
        return {"success": False, "error": "Commander not initialized"}

    result = commander.execute_goal(goal, runtime)
    return result


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Executive Agent - Local AI Operator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m src.main                          # Start interactive CLI
  python -m src.main --gui                    # Start GUI
  python -m src.main --goal "Create a Python script"  # Execute single goal
  python -m src.main --version                # Show version
        """,
    )

    parser.add_argument(
        "--gui",
        action="store_true",
        help="Start the GUI application",
    )

    parser.add_argument(
        "--goal",
        type=str,
        help="Execute a single goal and exit",
    )

    parser.add_argument(
        "--version",
        action="version",
        version="Executive Agent 1.0.0",
    )

    parser.add_argument(
        "--config",
        type=str,
        default="config/settings.yaml",
        help="Path to configuration file",
    )

    parser.add_argument(
        "--profile",
        type=str,
        default="profiles",
        help="Path to profiles directory",
    )

    args = parser.parse_args()

    # Print banner
    print_banner()

    # Load configuration
    config = load_app_config()

    # Build runtime
    print("Initializing components...")
    runtime = build_runtime()
    print("Ready!\n")

    # Execute based on arguments
    if args.gui:
        return start_gui()
    elif args.goal:
        result = asyncio.run(execute_single_goal(args.goal, runtime))
        print(f"\nResult: {result}")
        return 0 if result.get("success") else 1
    else:
        # Start interactive CLI
        start_cli_session()
        return 0


if __name__ == "__main__":
    sys.exit(main())
